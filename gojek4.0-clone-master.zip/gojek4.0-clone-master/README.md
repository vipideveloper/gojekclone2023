# gojekclone

Gojek 4.0 clone

this app not responsive, it might be look weird on ur phone. u can use lib screenutil to fix that
