package com.tr.gojekclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
